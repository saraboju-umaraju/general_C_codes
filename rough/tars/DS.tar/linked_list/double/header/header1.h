#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#define MAX 50

typedef struct node{
	int data;
	struct node *prev;
	struct node *next;
}NODE;

int validate (void);

void display (NODE*);

NODE* ins_begin (int, NODE*);

NODE* ins_end (int, NODE*);

NODE* at_pos (int, int, NODE*);

NODE* before_pos (int, int, NODE*);

NODE* after_pos (int, int, NODE*);

NODE* before_val (int, NODE*);

NODE* after_val (int, NODE*);

NODE* ins_mid (int, NODE*);

NODE* ins_penaltimate (int, NODE*);


NODE* rem_begin (NODE*);

NODE* rem_end (NODE*);

NODE* rem_at_pos (int, NODE*);

NODE* rem_before_pos (int, NODE*);

NODE* rem_after_pos (int, NODE*);

NODE* rem_before_val (NODE*);

NODE* rem_after_val (NODE*);

NODE* rem_mid (NODE*);

NODE* rem_penultimate (NODE*);

