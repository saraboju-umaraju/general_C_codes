#include "header1.h"

void display (struct node *head)
{
	NODE *temp = head;
		
	if (head == NULL) {
		printf ("List is Empty\n");
		return;
	}

	printf ("Elements in List : \n");
	while (temp->next != NULL) {
		printf ("%d  ", temp->data);
		temp = temp->next;
	}
	printf ("%d\n", temp->data);
}
