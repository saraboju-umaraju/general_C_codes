#include "header1.h"

NODE *ins_begin (int num, NODE *head)
{
	NODE *new = NULL;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (head == NULL) 
		head = new;

	else {
		new->next = head;
		head->prev = new;
		head = new;
	}

	return head;
}


NODE *ins_end (int num, NODE *head)
{
	NODE *temp = head;
	NODE *new = NULL;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (head == NULL)
		head = new;	

	else {
		while (temp->next != NULL)
			temp = temp->next;
	
		new->prev = temp;
		temp->next = new;
	}

	return head;
}
