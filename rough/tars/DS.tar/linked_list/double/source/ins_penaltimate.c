#include "header1.h"

NODE *ins_penaltimate (int num, NODE *head)
{
	NODE *new = NULL;
	NODE *temp = head;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (head == NULL)
		printf ("List is Empty\n");

	else if (temp->next == NULL) {
		new->next = temp;
		new->prev = NULL;
		temp->prev = new;
		head = new;
	}

	else {
		while (temp->next != NULL)
			temp = temp->next;

		new->next = temp;
		new->prev = temp->prev;
		temp->prev->next = new;
		temp->prev = new;
	}

	return head;
}
