#include "header1.h"

NODE *at_pos (int num, int pos, NODE *head)
{
	NODE *new = NULL;
	NODE *temp = head;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (pos == 1) {
		if (head == NULL)
			head = new;
		else {
			temp->prev = new;
			new->next = head;
			head = new;
		}			
	}

	else {
		while (--pos && (temp != NULL))
			temp = temp->next;

		if (temp == NULL)
				printf ("Position is out of List\n");		
		else {
			new->next = temp;
			new->prev = temp->prev;
			temp->prev->next = new;
			temp->prev = new;
		}
	}

	return head;
}




NODE *after_pos (int num, int pos, NODE *head)
{
	NODE *new = NULL;
    NODE *temp = head;

    new = malloc (sizeof (NODE));
    new->data = num;

	if (head == NULL)
		printf ("List is Empty\n");

    else {
        while (--pos && (temp->next != NULL))
            temp = temp->next;

		if ((pos == 0) && (temp->next == NULL)) {
			new->prev = temp;
			new->next = NULL;
			temp->next = new;				
		}

        else if(pos > 0)
                printf ("Position is out of List\n");

        else {
            new->next = temp->next;
            new->prev = temp;
            temp->next->prev = new;
            temp->next = new;
        }
    }

	return head;
}

 


NODE *before_pos (int num, int pos, NODE *head)
{
	NODE *temp = head;
	NODE *new = NULL;
	
	new = malloc (sizeof (NODE));
	new->data = num;

	if ((head == NULL) || (pos == 1))
        printf ("Not possible\n");

	else if (pos == 2) {
		new->next = head;
		new->prev = NULL;
		temp->prev = new;
		head = new;
	}

	else {
		pos--;
        while (--pos && (temp != NULL))
            temp = temp->next;

		if (temp == NULL)
                printf ("Position is out of List\n");\
	
        else {
          	new->prev = temp->prev;
            new->next = temp;
            temp->prev->next = new;
            temp->prev = new;
		}

    }

    return head;

}
