#include "header1.h" 

NODE *after_val (int num, NODE *head)
{
	NODE *temp = head;
	NODE *new = NULL;
	int value;

	new = malloc (sizeof (NODE));
	new->data = num;

	printf ("Enter the value present in the List\n");
	value = validate ();

	if (head == NULL)
		printf ("List is Empty\n");
	
	else {
		while ((temp->data != value) && (temp->next != NULL))
			temp = temp->next;

		if (temp->next != NULL) {
			new->next = temp->next;
			new->prev = temp;
			temp->next->prev = new;
			temp->next = new;
		}
	
		else if (temp->data == value) {
			new->prev = temp;
			temp->next = new;
			new->next = NULL;
		}
		
		else 
			printf ("Value Not found in the List\n");
	}

	return head;
}


NODE *before_val (int num, NODE *head)
{
	NODE *temp = head;
    NODE *new = NULL;
    int value;

    new = malloc (sizeof (NODE));
    new->data = num;

    printf ("Enter the value present in the List\n");
    value = validate ();

    if (head == NULL)
        printf ("List is Empty\n");

	else if (temp->data == value) {
		new->next = temp;
		temp->prev = new;
		head = new;
		new->prev = NULL;
	}

    else {
        while ((temp != NULL) && (temp->data != value))
            temp = temp->next;

        if (temp != NULL) {
            new->next = temp;
            new->prev = temp->prev;
            temp->prev->next = new;
            temp->prev = new;
        }

        else
            printf ("Value Not found in the List\n");
    }

    return head;
}

