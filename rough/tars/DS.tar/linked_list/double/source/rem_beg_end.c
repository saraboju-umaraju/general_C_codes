#include "header1.h"

NODE *rem_begin (NODE *head)
{
	NODE *temp = head;

	if (head == NULL)
		printf ("List is Empty\n");

	else if (temp->next == NULL)
		head = NULL;

	else {
		head = temp->next;
		temp->next->prev = NULL;
		free (temp);
		temp = NULL;
	}


	return head;
}



NODE *rem_end (NODE *head)
{
	NODE *temp = head;

	if (head == NULL)
		printf ("List is Empty\n");

	else if (temp->next == NULL)
        head = NULL;

	else {
		while (temp->next != NULL)
			temp = temp->next;
			
		temp->prev->next = NULL;
		free (temp);
		temp = NULL;
	}

	return head;
}
