#include "header1.h"


NODE *rem_mid (NODE *head)
{
	NODE *temp1 = head;
    NODE *temp2 = NULL;

    if (head == NULL) {
        printf ("List is Empty\n");
        return head;
    }

	else if (temp1->next == NULL) 
		printf ("Not possible since only one element in List\n");
	
    else if (temp1->next->next == NULL){
		head = temp1->next;
		temp1->next->prev = NULL;

		free (temp1);
		temp1 = NULL;
    }

	else {
		temp2 = temp1;
		while (temp1->next != NULL) {
			temp1 = temp1->next->next;
			if (temp1 == NULL)
				break;
			temp2 = temp2->next;
		}

		temp2->prev->next = temp2->next;
		temp2->next->prev = temp2->prev;

		free (temp2);
		temp2 = NULL;
	}

    return head;


}
