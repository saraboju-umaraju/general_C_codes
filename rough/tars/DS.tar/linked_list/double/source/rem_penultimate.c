#include "header1.h"


NODE *rem_penultimate (NODE *head)
{
	NODE *temp = head;
	
    if (head == NULL) {
        printf ("List is Empty\n");
        return head;
    }
	
	else if (temp->next == NULL) 
		printf ("No penultimate Element in the List\n");

	else if (temp->next->next == NULL) {
		head = temp->next;
		temp->next->prev = NULL;
		
		free (temp);
		temp = NULL;
	}

	else {
		while (temp->next->next != NULL)
			temp = temp->next;
		temp->prev->next = temp->next;
		temp->next->prev = temp->prev;

		free (temp);
		temp = NULL;
	}		
	
	return head;
}



