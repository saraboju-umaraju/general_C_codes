#include "header1.h"

NODE *rem_at_pos (int pos, NODE *head)
{
	NODE *temp = head;
	
	if (head == NULL) {
		printf ("List is Empty\n");
		return head;
	}

	else if (pos == 1) {
		if (temp->next == NULL)	
			head = NULL;
		else {
			head = temp->next;
			temp->prev = NULL;
		}
	}

	else {
		while (--pos && temp != NULL)
			temp = temp->next;
		
		if ( !pos && (temp != NULL)) 
			temp->prev->next = temp->next;	

		else  
			printf ("Position is out of List\n");
	}

	free (temp);
	temp = NULL;	

	return head;
}



NODE *rem_after_pos (int pos, NODE *head)
{
	NODE *temp1 = head;
	NODE *temp2 = NULL;

    if (head == NULL) {
        printf ("List is Empty\n");
        return head;
    }

    else if ((pos == 1) && (temp1->next == NULL))
    		printf ("No Element to remove\n");

    else {
        while (--pos && temp1->next != NULL) 
            temp1 = temp1->next;

		temp2 = temp1->next;		
		
        if ( !pos && (temp2 != NULL)) {
			if (temp2->next == NULL)
				temp1->next = NULL;
			else
				temp1->next = temp2->next;		
	
	    	free (temp2);
    		temp2 = NULL;
		}		

		else if ( !pos )
			printf ("No element to remove\n");

		else
			printf ("Position out of List\n");
	}
	
	return head;
}



NODE *rem_before_pos (int pos, NODE *head)
{
	NODE *temp1 = head;
    NODE *temp2 = NULL;

    if (head == NULL) {
        printf ("List is Empty\n");
        return head;
    }
	
	else if (pos == 1)
		printf ("Not possible\n");

	else if (pos == 2 && (temp1->next != NULL)) {
		head = temp1->next;
		temp1->next->prev = NULL;
		free (temp1);
		temp1 = NULL;
	}

    else {
		--pos;
        while (--pos && temp1 != NULL) {
			temp2 = temp1;
            temp1 = temp1->next;
		}

        if ( !pos && (temp1 != NULL)) {
            if (temp1->next == NULL)
                temp2->next = NULL;
            else {
                temp2->next = temp1->next;
				temp1->next->prev = temp2;
			}

            free (temp1);
            temp2 = NULL;
        }

        else
            printf ("Position out of List\n");
    }

	return head;
}
