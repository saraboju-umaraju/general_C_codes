#include "header1.h"


NODE *rem_after_val (NODE *head)
{
	NODE *temp1 = head;
	NODE *temp2 = NULL;
	int value;
	
	printf ("Enter the value\n");
	value = validate ();

    if (head == NULL) {
        printf ("List is Empty\n");
        return head;
    }
	
	else {
		while ((temp1->data != value) && (temp1->next != NULL)) 
			temp1 = temp1->next;
	
		if (temp1->next == NULL) {
			if (temp1->data == value)
				printf ("No Element after the value to remove\n");
			else
				printf ("Value Not found in the List\n");							
		}

		else {
			temp2 = temp1->next;
			temp1->next = temp2->next;
			if (temp2->next != NULL)
				temp2->next->prev = temp2->prev;

			free (temp2);
			temp2 = NULL;
		}
	}
	
	return head;
}



NODE *rem_before_val (NODE *head)
{
	NODE *temp1 = head;
    NODE *temp2 = NULL;
    int value;

    printf ("Enter the value\n");
    value = validate ();

    if (head == NULL) {
        printf ("List is Empty\n");
        return head;
    }

	else if (temp1->next == NULL) 
			printf ("Not possible since only one element in List\n");
	
	else if (temp1->next->data == value) {
			head = temp1->next;
			temp1->next->prev = NULL;

			free (temp1);
			temp1 = NULL;
	}
	
    else {
		temp1 = temp1->next->next;
        while ((temp1 != NULL) && (temp1->data != value))
            temp1 = temp1->next;

        if (temp1 == NULL) 
                printf ("Value Not found in the List\n");

        else {
            temp2 = temp1->prev;
            temp2->prev->next = temp1;
            temp1->prev = temp2->prev;

            free (temp2);
            temp2 = NULL;
        }
    }

    return head;


}
