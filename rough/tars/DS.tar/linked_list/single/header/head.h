#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define MAX 100

struct node {

		int data;
		struct node *link;
};

typedef struct node NODE;

NODE *add_begin(NODE *, int);

NODE *add_end(NODE *, int);

NODE *add_before_value(NODE *, int, int);

NODE *add_after_value(NODE *, int, int);

NODE *add_at_pos(NODE *, int, int);

NODE *add_before_pos(NODE *, int, int);

NODE *add_after_pos(NODE *, int, int);

NODE *add_mid(NODE *, int);

NODE *add_penaltimate(NODE *, int);

int valid_int(void);

NODE *delete_begin(NODE *);

NODE *delete_end(NODE *);

NODE *delete_at_pos(NODE *, int);

NODE *delete_by_value(NODE *, int);

void display(NODE *);

