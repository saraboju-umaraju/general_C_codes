#include    "head.h"                                                            

NODE *add_begin(NODE *head, int value)                                          
{                                                                               
		NODE *new = NULL;                                                           

		new = (NODE *)malloc(sizeof(NODE));                                         

		new -> data = value;                                                        

		if(head == NULL)                                                            

				head = new;                                                             

		else {                                                                      

				new -> link = head;                                                     
				head = new;                                                             
		}                                                                           
		return head;                                                                
} 

NODE *add_end(NODE *head, int value)                                            
{                                                                               
		NODE *new = NULL;                                                           
		NODE *temp = head;                                                          

		new = (NODE *)malloc(sizeof(NODE));                                         

		new -> data = value;                                                        

		if(head == NULL)                                                            

				head = new;                                                             

		else {                                                                      

				while(temp -> link != NULL)                                             

						temp = temp -> link;                                                

				temp -> link = new;                                                     
		}                                                                           
		return head;                                                                
}
