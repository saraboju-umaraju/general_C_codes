#include	"head.h"

NODE *add_mid(NODE *head, int value)
{
	NODE *slow = head;
	NODE *fast = head;
	NODE *new = NULL;

	if(head == NULL) {

		printf("List is empty\n");
		return head;
	}

	if(head -> link == NULL) {

		printf("mid is not posible\n");
		return head;
	}

	new = (NODE *)malloc(sizeof(NODE));
	
	new -> data = value;

	while(fast -> link && fast -> link -> link) {

		slow = slow -> link;
		fast = fast -> link -> link;
	}

	new -> link = slow -> link;
	slow -> link = new;
	return head;
}
