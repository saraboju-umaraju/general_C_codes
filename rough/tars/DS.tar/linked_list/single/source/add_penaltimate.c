#include	"head.h"

NODE *add_penaltimate(NODE *head, int value)
{
	NODE *temp = head;
	NODE *new = NULL;

	if(head == NULL) {

		printf("List is empty\n");
		return head;
	}

	new = (NODE *)malloc(sizeof(NODE));
	
	new -> data = value;

	if(temp -> link == NULL) {

		new -> link = head;
		head = new;
		return head;
	}

	else {

		while(temp -> link -> link)
		
			temp = temp -> link;

		new -> link = temp -> link;
		temp -> link = new;
		return head;
	}
}
