#include    "head.h"                                                            

NODE *add_at_pos(NODE *head, int value, int pos)                                
{                                                                               
		NODE *new = NULL;                                                           
		NODE *temp = head;                                                          

		new = (NODE *)malloc(sizeof(NODE));                                         

		new -> data = value;                                                        

		if(pos == 1) {                                                              

				new -> link = head;                                                     
				head = new;                                                             
				return head;                                                            
		}

		else if (head != NULL) {

				pos--;
				while(--pos && (temp -> link != NULL))                                  

						temp = temp -> link;                                                

				if(pos != 0) {                                                          

						printf("position is out of range\n");                               
						return head;                                                        
				}                                                                       

				else {

						new -> link = temp -> link;                                         
						temp -> link = new;                                                 
						return head;
				}
		}
		else                                                                        
				printf("position is out of range\n");

	return head;		
}


NODE *add_before_pos(NODE *head, int value, int pos)                            
{                                                                               
		NODE *new = NULL;                                                           
		NODE *temp = head;                                                          

		new = (NODE *)malloc(sizeof(NODE));                                         

		new -> data = value;                                                        

		if((head == NULL) && (pos == 1)) {                                          

				printf("position not posible\n");                                       
				return head;                                                            
		}                                                                           

		else if(pos == 1) {                                                         

				new -> link = head;                                                     
				head = new;                                                             
				return head;                                                            
		}                                                                           

		else {                                                                      

				pos -= 2;                                                               
				while(--pos && (temp -> link != NULL))                                  

						temp = temp -> link;                                                

				if(pos != 0) {                                                          

						printf("position is out of range\n");                               
						return head;                                                        
				}
				else {                                                                  

						new -> link = temp -> link;                                         
						temp -> link = new;                                                 
						return head;                                                        
				}                                                                       
		}                                                                           
}


NODE *add_after_pos(NODE *head, int value, int pos)                             
{                                                                               
		NODE *new = NULL;                                                           
		NODE *temp = head;                                                          

		new = (NODE *)malloc(sizeof(NODE));                                         

		new -> data = value;                                                        

		if(head == NULL) {                                                          

				printf("list is empty so position not posible\n");                      
				return head;                                                            
		}                                                                           

		else {                                                                      

				while(--pos && (temp -> link != NULL))                                  

						temp = temp -> link;                                                

				if(pos != 0) {                                                          

						printf("position is out of range\n");                               
						return head;                                                        
				}                                                                       

				else {                                                                  

						new -> link = temp -> link;                                         
						temp -> link = new;                                                 
						return head;                                                        
				}                                                                       
		}                                                                           
}
