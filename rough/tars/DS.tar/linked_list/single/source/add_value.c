#include    "head.h"                                                            

NODE *add_before_value(NODE *head, int value, int x)                            
{                                                                               
		NODE *new = NULL;                                                           
		NODE *temp = head;                                                          

		if(head == NULL) {                                                          

				printf("List is empty\n");                                              
				return head;                                                            
		}                                                                           

		new = (NODE *)malloc(sizeof(NODE));                                         

		new -> data = value;                                                        

		if(head -> data == x) {                                                     

				new -> link = head;                                                     
				head = new;                                                             
				return head;                                                            
		}                                                                           

		while((temp -> link != NULL) && (temp -> link -> data != x))                

				temp = temp -> link;                                                    

		if(temp -> link == NULL) {                                                  

				printf("element not found\n");                                          
				return head;                                                            
		}                                                                           
		else {                                                                      
				new -> link = temp -> link;                                             
				temp -> link = new;                                                     
				return head;                                                            
		}
}


NODE *add_after_value(NODE *head, int value, int x)                             
{                                                                               
		NODE *new = NULL;                                                           
		NODE *temp = head;                                                          

		if(head == NULL) {                                                          

				printf("List is empty\n");                                              
				return head;                                                            
		}                                                                           

		new = (NODE *)malloc(sizeof(NODE));                                         

		new -> data = value;                                                        

		while(temp -> data != x && temp -> link != NULL)                            

				temp = temp -> link;                                                    

		if(temp -> data == x) {                                                     

				new -> link = temp -> link;                                             
				temp -> link = new;                                                     
				return head;                                                            
		}                                                                           

		else {                                                                      
				printf("Element not found\n");                                          
				return head;                                                            
		}                                                                           
}
