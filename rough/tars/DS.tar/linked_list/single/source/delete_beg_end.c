#include    "head.h"                                                            

NODE *delete_begin(NODE *head)                                                  
{                                                                               
		NODE *temp = head;                                                          

		if(head == NULL) {                                                          

				printf("List is empty\n");                                              
				return head;                                                            
		}                                                                           

		else if(temp -> link == NULL) {                                             

				free(temp);                                                             
				head = NULL;                                                            
				return head;                                                            
		}                                                                           

		else {                                                                      

				head = head -> link;                                                    
				free(temp);                                                             
				temp = NULL;                                                            
				return head;                                                            
		}                                                                           
}


NODE *delete_end(NODE *head)                                                    
{                                                                               
		NODE *temp = head;                                                          
		NODE *prev = NULL;                                                          

		if(head == NULL) {                                                          

				printf("List is empty\n");                                              
				return head;                                                            
		}                                                                           

		else if(temp -> link == NULL) {                                             

				free(temp);                                                             
				head = NULL;                                                            
				return head;                                                            
		}                                                                           

		else {                                                                      

				while(temp -> link != NULL) {                                           

						prev = temp;                                                        
						temp = temp -> link;                                                
				}                                                                       

				free(temp);                                                             
				prev -> link = NULL;                                                    
				return head;                                                            
		}                                                                           
}
