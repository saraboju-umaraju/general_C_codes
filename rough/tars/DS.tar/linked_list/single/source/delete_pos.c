#include	"head.h"

NODE *delete_at_pos(NODE * head, int pos)
{
	NODE *prev, *temp;

	temp = head;

	if(head == NULL) {

		printf("List is empty\n");
		return head;
	}

	if(pos == 1) {

		head = head -> link;
		free(temp);
		temp = NULL;
		return head;
	}

	while(--pos && temp -> link != NULL) {

		prev = temp;
		temp = temp -> link;
	}
 	
	if(pos == 0) {

		prev -> link = temp -> link;
		free(temp);
		temp = NULL;
		return head;
	}

	else {

		printf("position is out of range\n");
		return head;
	}
}
