#include	"head.h"

NODE *delete_by_value(NODE * head, int x)
{
	NODE *prev, *temp;

	temp = head;

	if(head == NULL) {

		printf("list is empty\n");
		return head;
	}

	if(temp -> data == x) {

		head = head -> link;
		free(temp);
		temp = NULL;
		return head;
	}

	while(temp -> data != x && temp -> link != NULL) {

		prev = temp;
		temp = temp -> link;
	}
 	
	if(temp -> data == x) {
	
		prev -> link = temp -> link;
		free(temp);
		temp = NULL;
		return head;
	}

	else {

		printf("Element is not found\n");
		return head;
	}
}
