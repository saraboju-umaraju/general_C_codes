#include	"head.h"

void display(NODE *head)
{
	if(head == NULL) {

		printf("List is empty\n");
		return;
	}

	printf("Elements in list are\n");
	while(head) {

		printf("%d\t", head -> data);
		
		head = head -> link;
	}

	printf("\n");
}
