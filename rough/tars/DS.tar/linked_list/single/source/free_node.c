#include	"head.h"

void free_node(NODE *head)
{
	NODE *temp;
	
	while(head) {

		temp = head;
		head = head -> link;
		free(temp);
		temp = NULL;
	}
}
