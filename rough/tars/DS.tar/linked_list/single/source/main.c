#include	"head.h"

int main(void)
{
	NODE *head = NULL;
	int choice;
	int value;
	int item;
	int pos;

	while(1) {

		printf(".......Welcome to GES Ltd.......\n1: Insertion\n2: Deletion\n3: Display\n4: Exit\n.......Thank you GES.......\n"
			"Enter your choice from above menu\n");

		choice = valid_int();

		switch(choice) {

				case 1:
					
					printf(".......MENU.......\n1: add_begining\n2: add_end\n3: add_before_value\n4: add_after_value\n5: add_at_pos\n"
					"6: add_before_pos\n7: add_after_pos\n8: add_mid\n9: add_penaltimate\n.......END.......\nEnter your choice from menu\n");

					choice = valid_int();

					switch(choice) {

							case 1:

								printf("Enter the element to insert\n");
								value = valid_int();

								head = add_begin(head, value);
								break;

							case 2:

								printf("Enter the element to insert\n");
								value = valid_int();

								head = add_end(head, value);
								break;

							case 3:

								printf("Enter the element to insert\n");
								value = valid_int();

								printf("Enter element before which to insert\n");
								item = valid_int();

								head = add_before_value(head, value, item);
								break;

							case 4:

								printf("Enter the element to insert\n");
								value = valid_int();

								printf("Enter element after which to insert\n");
								item = valid_int();

								head = add_after_value(head, value, item);
								break;

							case 5:

								printf("Enter the element to insert\n");
								value = valid_int();

								printf("Enter position at which to insert\n");
								pos = valid_int();

								head = add_at_pos(head, value, pos);
								break;

							case 6:

								printf("Enter the element to insert\n");
								value = valid_int();

								printf("Enter position at which to insert\n");
								pos = valid_int();

								head = add_before_pos(head, value, pos);
								break;

							case 7:

								printf("Enter the element to insert\n");
								value = valid_int();

								printf("Enter position at which to insert\n");
								pos = valid_int();

								head = add_after_pos(head, value, pos);
								break;

							case 8:

								printf("Enter the element to insert\n");
								value = valid_int();

								head = add_mid(head, value);
								break;

							case 9:

								printf("Enter the element to insert\n");
								value = valid_int();

								head = add_penaltimate(head, value);
								break;

							default: printf("Invalid choice\n");
					}
					break;

				case 2:
					
					printf(".......MENU.......\n1: delete_begining\n2: delete_end\n3: delete_at_pos\n4: delete_by_value\n.......END.......\n"
							"Enter your choice from menu\n");
					
					choice = valid_int();

					switch(choice) {

							case 1:
								
								head = delete_begin(head);
								break;

							case 2:

								head = delete_end(head);
								break;

							case 3:

								printf("Enter the position\n");
								pos = valid_int();
								
								head = delete_at_pos(head, pos);
								break;

							case 4:

								printf("Enter the element to delete\n");
								value = valid_int();

								head = delete_by_value(head, value);
								break;

							default: printf("Invalid choice\n");
					}
					break;

				case 3:

					display(head);
					break;

				case 4: 
					exit(0);
					//free_node(head);
					//return 0;

				default: printf("Invalid choice\n");
		}
	}
	return 0;
}
