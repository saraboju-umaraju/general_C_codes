#include	"head.h"

int valid_int(void)
{
	char c;
	int i = 0;
	char s[MAX];
	int temp = 1;
	double sum = 0;
	int dot = 0;
	int range = 1;
	int dt = 0;


	for(i = 0; i < MAX - 1 && (c = getchar()) != EOF && c != '\n'; i++) {

		if(0 == i && (c == ' ' || c == '\t'))
			i--;

		else
			s[i] = c;
	}

	s[i] = '\0';
	for(i = strlen(s) - 1; i >= 0; i--) {

		if(s[i] == ' ' || s[i] == '\t')
			s[i] = '\0';

		else
			break;
	}

	i = 0; 
		if(s[0] == '+' || s[0] == '-') {
			i = 1;
		}
	
		for(; s[i] != '\0'; i++) {

			if(s[i] == '.') {

				++dot;
				continue;
			}

			if(s[i] >= '0' && s[i] <= '9' && dot <= 1)

				sum = sum * 10 + (s[i] - '0');
			
			else {
				temp = 0;
				break;
			}
		}
	for(i = 1; i < (8 * sizeof(int)); i++)
		range = range * 2;

	i = strlen(s) - 1;

	if(1 == temp && dot <= 1 && s[0] != '\0' && s[i] != '.' && s[i] != '+' && s[i] != '-' ) {
		for(; i >= 0; i--) {

		if(s[i] == '.') {

			dt = i;
			for(i = strlen(s) - 1; i > dt; i--) 
				sum /= 10;
			break;
		}
	}	
	if(s[0] == '-')
		sum *= -1;

	if(sum >= -range && sum <= range - 1) { 
//		printf("%d is a valid integer\n", (int)sum);
		return ((int)sum);
	}
	else
		printf("Given value is out of range\nRe-enter the value within the range: ");
	}
	else
		printf("It is not a valid integer\nRe-enter the valid integer: ");

//	exit (0);
	return valid_int();
}
