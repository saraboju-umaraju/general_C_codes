#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#define MAX 50

typedef struct node{
	int data;
	struct node *link;
}NODE;

void exit_n (NODE*);

int validate (void);

void display (NODE*);

NODE* ins_begin (int, NODE*);

NODE* rem_begin (NODE*);

NODE* ins_end (int, NODE*);

NODE* rem_end (NODE*);

NODE* at_pos (int, int, NODE*);

NODE* rem_at_pos (int, NODE*);

NODE* before_pos (int, int, NODE*);

NODE* rem_before_pos (int, NODE*);

NODE* after_pos (int, int, NODE*);

NODE* rem_after_pos (int, NODE*);

NODE *before_val (int, NODE*);

NODE *after_val (int, NODE*);

NODE *ins_mid (int, NODE*);

NODE *ins_penultimate (int, NODE*);

