#include "header1.h"

void exit_n (NODE *head)
{
	NODE *temp;
	NODE *temp1 = head;

	if (head == NULL)
		return;

	else {
		while (head->link != temp1) {
			temp = head;
			head = head->link; 

			free (temp);
			temp = NULL;
		}
		free (head);
		head = NULL;
	}

	return;
}
