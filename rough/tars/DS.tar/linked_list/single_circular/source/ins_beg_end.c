#include "header1.h"

NODE *ins_begin (int num, NODE *head)
{
	NODE *new = NULL;
	NODE *temp = head;

	new = malloc (sizeof (NODE));
	new->data = num;	

	if (head == NULL) {
		head = new;	
		new->link = head;
	}

	else {
		while (temp->link != head)
			temp = temp->link;
	
		new->link = head;
		temp->link = new;
		head = new;
	}

	return head;
}


NODE *ins_end (int num, NODE *head)
{
	NODE *new = NULL;
    NODE *temp = head;

    new = malloc (sizeof (NODE));
	new->data = num;

    if (head == NULL) {
        head = new;
        new->link = head;
    }

    else {
        while (temp->link != head)
            temp = temp->link;

        new->link = head;
        temp->link = new;
    }

	return head;
}
