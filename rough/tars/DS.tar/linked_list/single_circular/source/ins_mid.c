#include "header1.h"

NODE *ins_mid (int num, NODE *head)
{
	NODE *temp1 = NULL;
	NODE *temp2 = head;
	NODE *new = NULL;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (head == NULL)
		printf ("List is Empty\n");
	
	else if (temp2->link == head)
		printf ("Only one element in the List\n");

	else {
		temp1 = temp2;
		while (temp1->link->link != head) {
			temp1 = temp1->link->link;
			if (temp1->link == head) 				
				break;
			temp2 = temp2->link;				
		}		

		new->link = temp2->link;
		temp2->link = new;
	}

	return head;
}




