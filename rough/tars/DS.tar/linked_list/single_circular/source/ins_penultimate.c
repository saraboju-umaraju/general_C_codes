#include "header1.h"

NODE *ins_penultimate (int num, NODE *head)
{
	NODE *new = NULL;
	NODE *temp = head;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (head == NULL)
		printf ("List is Empty\n");

	else if (temp->link == head) {
		new->link = head;
		temp->link = new;
		head = new;
	}

	else {
		while (temp->link->link != head)
			temp = temp->link;

		new->link = temp->link;
		temp->link = new;
	}

	return head;
}
