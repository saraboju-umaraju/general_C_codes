#include "header1.h"

NODE *at_pos (int num, int pos, NODE *head)
{
	NODE *new = NULL;
	NODE *temp = head;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (pos == 1) {
		if (head == NULL) {
			head = new;
			new->link = head;
		}
		else {
			new = temp->link;
			temp->link = new;	
		}
	}

	else {
		--pos;
		while (--pos && (temp->link != head))
			temp = temp->link;
		
		if (pos == 0) {
			if (temp->link != head) {
				new->link = temp->link;		 
				temp->link = new;
			}
		
			else {
				new->link = temp->link;	
				temp->link = new;
			}	
		}
		else
			printf ("Position is Out of List\n");

	}

	return head;
}


NODE *after_pos (int num, int pos, NODE *head)
{
	NODE *new = NULL;
	NODE *temp = head;

	new = malloc (sizeof (NODE));
	new->data = num;

	if (head == NULL)
		printf ("List is Empty\n");

	else {
		while (--pos && (temp->link != head))
			temp = temp->link;

		if (pos == 0) {
			if (temp->link == head) {
				new->link = head;
				temp->link = new;	
			}
			else {
				
				new->link = temp->link;
				temp->link = new;
			}
		}
		else
			printf ("Position out of List\n");
	}

	return head;
}


NODE *before_pos (int num, int pos, NODE *head)
{
	NODE *new = NULL;
    NODE *temp = head;

    new = malloc (sizeof (NODE));
    new->data = num;

	if (head == NULL)
		printf ("List is Empty\n");

	else if (pos == 2) {
		while (temp->link != head)
			temp = temp->link;
		new->link = head;
		temp->link = new;
		head = new;
	}

    else {
        pos -= 2;
        while (--pos && (temp->link != head))
            temp = temp->link;

        if (pos == 0) {
            if (temp->link != head) {
                new->link = temp->link;
                temp->link = new;
            }

            else {
                new->link = temp->link;
                temp->link = new;
            }
        }
        else
            printf ("Position is Out of List\n");

    }

	return head;
}
