#include "header1.h"

NODE *after_val (int num, NODE *head)
{
	NODE *new = NULL;
	NODE *temp = head;
	int value;

	new = malloc (sizeof (NODE));
	new->data = num;
	
	printf ("Enter the value\n");
	value = validate ();

	if (head == NULL)
		printf ("List is Empty\n");

	else {
		while ((temp->data != value) && (temp->link != head))
			temp = temp->link;
	
		if (temp->link != head) {
			new->link = temp->link;
			temp->link = new;
		}

		else if (temp->data == value) {
			new->link = head;	
			temp->link = new;			
		}
		
		else
			printf ("Value Not found in the List\n");
	}

	return head;
}


NODE *before_val (int num, NODE *head)
{
	NODE *new = NULL;
    NODE *temp = head;
	NODE *temp1 = NULL;
	int value;

    new = malloc (sizeof (NODE));
    new->data = num;

	if (head == NULL)
		printf ("List is Empty\n");

	printf ("Enter the value\n");
    value = validate ();

    if (head == NULL)
        printf ("List is Empty\n");

    else {
        while ((temp->data != value) && (temp->link != head)) {
			temp1 = temp;
            temp = temp->link;
		}
	
		if (head->data == value) {
			new->link = head;
			while (temp->link != head)
				temp = temp->link;
			temp->link = new;
			head = new;
		}

        else if (temp->link != head) {
            new->link = temp1->link;
            temp1->link = new;
        }

        else if (temp->data == value) {
            new->link = temp;
            temp1->link = new;
        }

        else
            printf ("Value Not found in the List\n");
    }

	return head;
}
