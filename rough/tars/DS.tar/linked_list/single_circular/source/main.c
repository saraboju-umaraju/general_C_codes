#include "header1.h"

int main (void)
{
	int num;
	int ch;
	int choice;
	int pos;
	NODE *head = NULL;

	while (1) {
		
		printf (".....WELCOME TO GES Ltd.....\n1.INSERT\n2.REMOVE\n3.Display\n4.Exit\n.....Thank you GES.....\nEnter your choice\n");
		choice = validate ();

		if ((choice == 1) || (choice == 2)) {

			printf (".....MENU.....\n1.at beginning\n2.at end\n3.at position\n4.before position\n5.after position\n"
					"6.Before value\n7.After value\n8.at mid\n9.at penaltimate\n.....END.....\nEnter your choice\n");
			ch = validate ();
	
			if ((choice == 1) || (choice == 2)) {
				if ((ch > 2) && (ch < 6)) {
					printf ("Enter the position\n");
					pos = validate ();
				}
			}
			
			if ((choice == 1) && (ch < 10)) {
				printf ("Enter the number to insert \n");
				num = validate ();
			}
		}
		switch (choice) {

			case 1:
				switch (ch) {
					case 1 : 
						head = ins_begin (num, head);
						break;

					case 2 : 
						head = ins_end (num, head);
                    	break;
			
					case 3 : 
						head = at_pos (num, pos, head);
						break;

					case 4 : 
						head = before_pos (num, pos, head);
						break;
	
					case 5 : 
						head = after_pos (num, pos, head);
						break;

					case 6 : 
						head = before_val (num, head);
						break;	

					case 7 : 
						head = after_val (num, head);
						break;

					case 8 :
						head = ins_mid (num, head);
						break;

					case 9 : 
						head = ins_penultimate (num, head);
						break;

					default : printf ("Incorrect choice\n");
				}
				break;
		
			case 2 : 
				switch (ch) {
					case 1 : 
						head = rem_begin (head);
						break;
				
					case 2 : 
						head = rem_end (head);
						break;

					case 3 : 
						head = rem_at_pos (pos, head);
						break;

					case 4 : 
						head = rem_after_pos (pos, head);
						break;

					default : printf ("Incorrect choice\n");
				}
				break;

			case 3 : 
				display (head);
                break;

            case 4 : 
				exit_n (head);
				return 0 ;

			default : printf ("Incorrect choice\n");
		}
	}
	return 0;
}
