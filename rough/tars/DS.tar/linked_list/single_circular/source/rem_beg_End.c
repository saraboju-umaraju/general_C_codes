#include "header1.h"

NODE *rem_begin (NODE *head)
{
	NODE *temp = head;
	NODE *temp1 = head;

	if (head == NULL)
		printf ("List is Empty\n");

	else if (temp->link == head)
		head = NULL;

	else {
		while (temp->link != head)
			temp = temp->link;

		temp->link = temp1->link;
		head = temp1->link;

		free (temp1);
		temp1 = NULL;
	}

	return head;
}


NODE *rem_end (NODE *head)
{
	NODE *temp = head;
	NODE *temp1 = head;

	if (head == NULL)
		printf ("List is Empty\n");

	else if (temp->link == head)
        head = NULL;

	else {
		while (temp->link != head) {
			temp1 = temp;
			temp = temp->link;
		}
	
		temp1->link = temp->link;		
	
		free (temp);
		temp = NULL;
	}

	return head;
}
