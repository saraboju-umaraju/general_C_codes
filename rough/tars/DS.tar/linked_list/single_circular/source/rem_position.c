#include "header1.h"

NODE *rem_at_pos (int pos, NODE *head)
{
	NODE *temp = head;
	NODE *temp1 = NULL;
	
	if (head == NULL) {
		printf ("List is Empty\n");
		return head;
	}

	else if (pos == 1) {
		if (temp->link == head)	
			head = NULL;
		else 
			head = temp->link;
	}

	else {
		while (--pos && temp != head) {
			temp1 = temp;
			temp = temp->link;				
		}

		if ( !pos && (temp != head)) 
			temp1->link = temp->link;	

		else  
			printf ("Position is out of List\n");
	}

	free (temp);
	temp = NULL;	

	return head;
}


NODE *rem_after_pos (int pos, NODE *head)
{
	NODE *temp1 = head;
	NODE *temp2 = NULL;

    if (head == NULL) {
        printf ("List is Empty\n");
        return head;
    }

    else if ((pos == 1) && (temp1->link == head))
    		printf ("No Element to remove\n");

    else {
        while (--pos && temp1->link != head) 
            temp1 = temp1->link;

		temp2 = temp1->link;		
		
	
	return head;

	}
}
