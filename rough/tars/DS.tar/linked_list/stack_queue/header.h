#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define MAX 100

struct node {

		int data;
		struct node *link;
};

struct node *push(struct node *, int);

struct node *pop(struct node *);

void display(struct node *);

struct node *enqueue(struct node *, int);

struct node *dequeue(struct node *);

void print(struct node *);

int valid_int(void);

