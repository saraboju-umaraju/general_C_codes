#include	"header.h"

int main(void)
{
	struct node *rear = NULL;	
	int choice;
	int value;

	while(1) {
		
		printf("1: Enqueue\n2: dequeue\n3: print\n4: exit\nEnter your choice\n");
		choice = valid_int();

		switch(choice) {

			case 1:

				printf("Enter the element you want to insert\n");
				value = valid_int();

				rear = enqueue(rear,value);
				break;

			case 2:

				rear = dequeue(rear);
				break;

			case 3:

				print(rear);
				break;

			case 4:
				exit(0);
			
			default: printf("Invalid choice\n");
		}
	}
	return 0;
}

struct node *enqueue(struct node *rear, int value)
{
	struct node *new = NULL;

	new = (struct node *)malloc(sizeof(struct node));

	new -> data = value;
	
	if(rear == NULL) {

		rear = new;
		new -> link = NULL;
	}

	else {
		
		new -> link = rear;
		rear = new;
	}
	return rear;
}

struct node *dequeue(struct node *rear)
{
	struct node *front = rear;
	struct node *temp = rear;
	
	if(rear == NULL) 

		printf("stack is empty\n");
	
	else {

		while(front -> link != NULL) {

			temp = front;
			front = front -> link;
		}

		temp -> link = front -> link;
		
		printf("%d is deleted\n", front -> data);

		free(front);
	}

	return rear;
}

void print(struct node *rear)
{
	struct node *temp = rear;
	
	if(rear == NULL)

		printf("stack is empty\n");

	else {
		while(temp) {

			printf("%d\t", temp -> data);
			temp = temp -> link;
		}
		printf("\n");
	}
}
