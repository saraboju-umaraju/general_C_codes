#include	"header.h"

int main(void)
{
	struct node *top = NULL;
	int ch;
	int value;

	while(1) {
		
		printf("1: push\n2: pop\n3: Display\n4: exit\nEnter your choice\n");
		ch = valid_int();

		switch(ch) {

			case 1:

				printf("Enter the element you want to push\n");
				value = valid_int();

				top = push(top,value);
				break;

			case 2:

				top = pop(top);
				break;

			case 3:

				display(top);
				break;

			case 4:
				exit(0);
			
			default: printf("Invalid choice\n");
		}
	}
	return 0;
}

struct node *push(struct node *top, int value)
{
	struct node *new = NULL;

	new = (struct node *)malloc(sizeof(struct node));

	new -> data = value;
		
	new -> link = top;
	top = new;

	return top;
}

struct node *pop(struct node *top)
{
	struct node *temp = top;
	
	if(top == NULL) 

		printf("stack is empty\n");
	
	else {

		top = temp -> link;
		
		printf("%d is popped\n", temp -> data);

		free(temp);
	
		temp -> link = NULL;
	}

	return top;
}

void display(struct node *top)
{
	struct node *temp = top;
	
	if(top == NULL)

		printf("stack is empty\n");

	else {
		while(temp) {

			printf("%d\t", temp -> data);
			temp = temp -> link;
		}
		printf("\n");
	}
}
