#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define MAX 15

void linear(int *, int, int);

void binary(int *, int, int);

void insertion(int *, int);

