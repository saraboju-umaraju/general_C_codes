#include	"head.h"

void binary(int *a, int n, int key)
{
	int low;
	int high;
	int mid;

	low = 0;
	high = n -1;

	while(low < high) {

		mid = (low + high) / 2;

		if(key < a[mid])

			high = mid - 1;

		else if(key > a[mid])

			low = mid + 1;
		
		else {
			printf("%d is found\n", key);
			return;
		}
	}
	printf("%d is not found\n", key);
}
