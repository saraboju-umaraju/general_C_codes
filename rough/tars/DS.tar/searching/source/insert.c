#include	"head.h"

void insertion(int a[], int n)
{
	int i;
	int j;
	int temp;

	for(i = 1; i < n; i++) {

		temp = a[i];
		
		for(j = i - 1; temp < a[j] && j >= 0; j--)

			a[j + 1] = a[j];
	
		a[j + 1] = temp;
	}
}
