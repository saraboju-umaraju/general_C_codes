#include	"head.h"

void linear(int *a, int n, int key)
{
	int i;

	for(i = 0; i < n; i++) {

		if(key == a[i]) {

			printf("%d is found at %dth position\n", key, i + 1);
			return;
		}
	}
	printf("%d is not found\n", key);
}
