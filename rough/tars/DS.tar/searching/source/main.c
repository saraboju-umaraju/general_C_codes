#include	"head.h"

int main(void)
{
	int size;
	int key;
	int i;
	int choice;

	printf("Enter the array size\n");
	size = valid_int();

	int arr[size];

	printf("Enter elements into array\n");
	
	for(i = 0; i < size; i++)

		arr[i] = valid_int();

	printf("Enter the element you want to search\n");
	key = valid_int();

	printf("1: Linear search\n2: Binary search\nEnter your choice from menu\n");
	choice = valid_int();

	switch(choice) {

			case 1:
				
				linear(arr, size, key);	
				break;

			case 2:
				
				insertion(arr, size);

				binary(arr, size, key);
				break;

			default:
				printf("Invalid Input\n");
	}
	return 0;
}
