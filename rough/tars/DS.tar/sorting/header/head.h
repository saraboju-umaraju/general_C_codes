#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define MAX 15

void bubble(int *, int);

void selection(int *, int);

void insertion(int *, int);

void swap(int *, int *);

void divide(int *, int, int);

void quick_sort(int *, int, int);

int partition_1(int *, int, int);

int partition_2(int *, int, int);

void merge(int *, int, int, int);

