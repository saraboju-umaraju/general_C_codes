#include	"head.h"

void bubble(int a[], int n)
{
	int i;
	int j;
	int order;

	printf("1: Ascending order\n2: Descending order\nselect your order from above\n");
	order = valid_int();

	for(i = 0; i < n; i++) {

		for(j = 0; j < n - i - 1; j++) {

			if(order == 1) {

				if( a[j] > a[j + 1] )

					swap( &a[j], &a[j + 1] );
			}
			
			else if(order == 2) {

				if( a[j] < a[j + 1] )

					swap( &a[j], &a[j + 1]);
			}
			else {
				printf("Invalid choice\n");
				return;
			}
		}
	}
	printf("Elements after sorting\n");

	for(i = 0; i < n; i++)
		printf("%d\t", a[i]);

	printf("\n");
}
