#include	"head.h"

void divide(int *a, int low, int high)
{
	int mid;

	if(low < high) {

		mid = (low + high) / 2;

		divide(a, low, mid);

		divide(a, mid + 1, high);

		merge(a, low, mid, high);
	}
}
