#include	"head.h"

void insertion(int a[], int n)
{
	int i;
	int j;
	int temp;
	int order;

	printf("1: Ascending order\n2: Descending order\nselect your order from above\n");
	order = valid_int();

	for(i = 1; i < n; i++) {

		temp = a[i];
		
		if(order == 1) {
		
			for(j = i - 1; temp < a[j] && j >= 0; j--)

				a[j + 1] = a[j];
		}
		else if(order == 2) {
		
			for(j = i - 1; temp > a[j] && j >= 0; j--)

				a[j + 1] = a[j];
		}
		else {
			printf("Invalid choice\n");
			return;
		}

		a[j + 1] = temp;
	}
	printf("Elements after sorting\n");

	for(i = 0; i < n; i++)
		printf("%d\t", a[i]);

	printf("\n");
}
