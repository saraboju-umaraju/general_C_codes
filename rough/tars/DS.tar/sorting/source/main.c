#include	"head.h"

int main(void)
{
	int size;
	int i;
	int choice;

	printf("Enter how many elements you want to sort\n");
	size = valid_int();

	int arr[size];

	printf("Enter the elements into array\n");
	
	for(i = 0; i < size; i++)

		arr[i] = valid_int();

	printf("Elements before sorting\n");
	
	for(i = 0; i < size; i++)
		printf("%d\t", arr[i]);

	printf("\n1: Bubble sort\n2: Selection sort\n3: Insertion sort\n4: Merge sort\n5: Quick sort\nEnter your choice from menu\n");
	choice = valid_int();

	switch(choice) {

			case 1:
				
				bubble(arr, size);	
				break;

			case 2:

				selection(arr, size);
				break;

			case 3:

				insertion(arr, size);
				break;

			case 4:

				divide(arr, 0, size - 1);
				
				printf("Elements after sorting\n");
				
				for(i = 0; i < size; i++)
					printf("%d\t", arr[i]);
				
				printf("\n");
				
				break;

			case 5:

				quick_sort(arr, 0, size - 1);
				
				printf("Elements after sorting\n");
				
				for(i = 0; i < size; i++)
					printf("%d\t", arr[i]);
				
				printf("\n");
				
				break;

			default:
				printf("Invalid Input\n");
	}
	return 0;
}
