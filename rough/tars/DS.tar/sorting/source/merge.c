#include	"head.h"

void merge(int *arr, int low, int mid, int high)
{
	int temp[50];
	int i = low;
	int j = mid + 1;
	int k = low;

	while(i <= mid && j <= high) {
		
		if(arr[i] <= arr[j]) {

			temp[k] = arr[i];
			i++;
			k++;
		}
		else {

			temp[k] = arr[j];
			j++;
			k++;
		}
	}

	while(i <= mid)

		temp[k++] = arr[i++];

	while(j <= high)

		temp[k++] = arr[j++];

	for(i = 0; i <= high; i++)

		arr[i] = temp[i];
}
