#include	"head.h"

int partition_1(int *a, int low, int high)
{	
	int pivot = a[low];
	int i = low + 1;
	int j = high;

	while(1) {
		
		while(a[i] < pivot && i <= j)

			i++;

		while(a[j] > pivot && j >= i)

			j--;

		if(i < j)

			swap(&a[i], &a[j]);
		
		else if(i >= j) 
			swap(&a[low], &a[j]);

		break;
	}

	return j;
}
