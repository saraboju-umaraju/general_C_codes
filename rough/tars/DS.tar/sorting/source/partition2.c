#include	"head.h"

int partition_2(int *a, int low, int high)
{
	int i;
	int j;
	int pivot;

	i = low - 1;
	pivot = a[high];

	for(j = low; j <= (high - 1); j++) {

		if(a[j] <= pivot) {

			i++;
			swap(&a[i], &a[j]);
		}
	}

	swap(&a[high], &a[i + 1]);

	return (i + 1);
}
