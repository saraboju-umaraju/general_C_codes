#include	"head.h"

void quick_sort(int *a, int low, int high)
{
	int p;

	if(low >= high)

		return;

//	p = partition_1(a, low, high);
	
	p = partition_2(a, low, high);

	quick_sort(a, low, p - 1);

	quick_sort(a, p + 1, high);
}
