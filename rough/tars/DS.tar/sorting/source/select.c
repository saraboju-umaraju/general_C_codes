#include	"head.h"

void selection(int a[], int n)
{
	int i;
	int j;
	int min_idx;

	for(i = 0; i < n - 1; i++) {

		min_idx = i;

		for(j = i + 1; j < n; j++) {

			if( a[j] < a[min_idx] )

				min_idx = j;
		}
		swap( &a[i], &a[min_idx]);
	}
	printf("Elements after sorting\n");

	for(i = 0; i < n; i++)
		printf("%d\t", a[i]);

	printf("\n");
}
