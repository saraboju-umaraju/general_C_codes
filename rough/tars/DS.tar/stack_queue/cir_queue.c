#include	"header.h"

int arr[MAX];	
int front = -1;	
int rear = -1;

int main(void)
{
	int choice;

	while(1){
			
		printf("\n1. Enqueue\n2. Dequeue\n3. Display\n4. Exit\nEnter Ur choice: ");
		choice = valid_int();

		switch(choice) {

			case 1 :
				
				inserts();
				break;

			case 2 :
								
				deletes();
				break;

			case 3 :
								
				print();
				break;

			case 4 :				
				exit(0);

			default : printf("Invalid option\n");
		}

	}
	return 0;
}


/*void inserts(void)
{
	int value;

	if((front == 0 && rear == MAX - 1) || (front > 0 && front == rear + 1))
		
		printf("Queue is full\n");

	else {
				
		printf("Enter a element to insert: ");
		value = valid_int();

		if(rear == MAX - 1 && front > 0) {

			rear = 0;
			arr[rear] = value;
		}
		else if((front == 0 && rear == -1) || (rear != front - 1))

			arr[++rear] = value;
	}
}*/


void inserts(void)
{
	int value;

	if(front == rear + 1 || (front == 0 && rear == MAX - 1)) {

		printf("Queue is full\n");
		return;
	}

	if(front == -1)

		front = 0;

	else if(rear == MAX - 1)

		rear = 0;

	else 
		rear++;

	printf("Enter a element to insert: ");	
	value = valid_int();

	arr[rear] = value;
}


/*void deletes(void)
{
	int value;

	if((front == 0) && (rear == -1)) {

		printf("Queue is empty\n");
		return;
	}

	if(front == rear) {
		
		value = arr[front];
		rear = -1;
		front = 0;
	}

	else if(front == MAX - 1) {

		value = arr[front];
		front = 0;
	}
	else

		value = arr[front++];

	printf("%d is deleted\n", value);
}*/


void deletes(void)
{
	if(front == -1) {

		printf("Queue is empty\n");
		return;
	}

	if(front == rear) {

		front = -1;
		rear = -1;
	}

	else if(front == MAX - 1)

		front = 0;

	else
		front++;
}


/*void print(void)
{
	int i;
	int j;

	if(rear == -1 && front == 0) {
				
		printf("Queue is empty\n");
		return;
	}
	
	if(front > rear) {
				
		for(i = 0; i <= rear; i++)
						
			printf("%d\t", arr[i]);
		
		for(j = front; j <= MAX - 1; j++)

			printf("%d\t", arr[j]);
	}
	else {			
		
		for(i = front; i <= rear; i++)
		
			printf("%d\t", arr[i]);
	}
	printf("\n");
}*/


void print(void)
{
	int x = front;

	if(front == -1) {

		printf("Queue is empty\n");
		return;
	}

	if(front <= rear) {

		while(x <= rear) {

			printf("%d\t", arr[x]);
			x++;
		}
	}

	else {

		while(x <= MAX - 1) {

			printf("%d\t", arr[x]);
			x++;
		}

		x = 0;

		while(x <= rear) {

			printf("%d\t", arr[x]);
			x++;
		}
	}
	printf("\n");
}
