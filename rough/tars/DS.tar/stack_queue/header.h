#include    <stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define MAX 10
                                                                                
void push(int);                                                                 

void pop(void);                                                                  

void stack_display(void);

int valid_int(void);

int enqueue(int *, int, int);

int dequeue(int *, int, int);

void queue_display(int *, int, int);

void inserts(void);

void deletes(void);

void print(void);

