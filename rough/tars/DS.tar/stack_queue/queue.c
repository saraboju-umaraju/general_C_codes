#include	"header.h"

int main(void)
{
	int choice;
	int arr[MAX];
	int front = 0;
	int rear = 0;
	
	while(1){
			
		printf("\n1. Enqueue\n2. Dequeue\n3. Display\n4. Exit\nEnter Ur choice:");
		choice = valid_int();

		switch(choice) {

			case 1 :
				
				rear = enqueue(arr, rear, MAX);
				break;

			case 2 :
								
				front = dequeue(arr, front, rear);
				break;

			case 3 :
								
				queue_display(arr, rear, front);
				break;

			case 4 :				
				
				exit(0);
				break;

			default : printf("Invalid option\n");
		}

	}
	return 0;
}

int enqueue(int *a, int r, int size)
{
	int value;

	if(r == size)
		
		printf("Queue is full\n");

	else {
				
		printf("Enter a element: ");
		value = valid_int();

		a[r] = value;
		r++;
	}

	return r;
}

int dequeue(int *a, int f, int r)
{
	int value;

	if(f == r)
				
		printf("Queue is empty\n");
		
	else {
		
		value = a[f];
		f++;

		printf("%d is deleted\n", value);
	}

	return f;
}

void queue_display(int *a, int r, int f)
{
	if(r == f)
				
		printf("Queue is empty\n");
	
	else {
				
		while(f < r){
						
			printf("%d\t", a[f]);
			f++;
		}
		printf("\n");
	}
}
