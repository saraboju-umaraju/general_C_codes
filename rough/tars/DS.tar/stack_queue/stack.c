#include	"header.h"

int top = -1;
int arr[MAX];

int main(void)
{
	int value;
	int choice;

	while(1) {
		
		printf("\n1: push\n2: pop\n3: Display\n4: Exit\nEnter your choice: ");
		choice = valid_int();

		switch(choice) {

			case 1:

				printf("Enter the element: ");
				value = valid_int();

				push(value);
				break;

			case 2:

				pop();			
				break;

			case 3:

				stack_display();
				break;

			case 4: exit(0);
			
			default: printf("Invalid choice\n");
		}
	}
	return 0;
}

void push(int value)
{
	if(top == (MAX - 1))

		printf("stack is overflow\n");
	
	else {

		top++;
		arr[top] = value;
	}
}

void pop(void)
{
	if(top == -1) { 

		printf("stack is underflow\n");
		return;
	}

	printf("%d is popped\n", arr[top--]);
}

void stack_display(void)
{
	int i;

	if(top == -1) {

		printf("stack is underflow\n");
		return;
	}
	
	printf("Elements in stack are:\n");
	
	for(i = 0; i <= top; i++)

		printf("%d\t", arr[i]);
	
	printf("\n");
}
