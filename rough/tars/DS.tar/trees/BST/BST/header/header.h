#ifndef HEADER_H
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#define MAX 100

typedef struct tree {

		int data;
		struct tree *left;
		struct tree *right;
}TREE;

TREE *insert(TREE *, TREE *);

TREE *deleted(TREE *, int);

TREE *max_bst(TREE *);

void inorder(TREE *);

void preorder(TREE *);

void postorder(TREE *);

int search(TREE *, int);

int valid_int(void);

#endif
