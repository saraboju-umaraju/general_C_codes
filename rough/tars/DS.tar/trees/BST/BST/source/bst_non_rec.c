#include	<stdio.h>
#include	<stdlib.h>

struct node {
	struct node *lchild;
	int data;
	struct node *rchild;
};

typedef struct node NODE;

int val = 0;

NODE *insertion(NODE * root,int val);

void display(NODE *root);

void search_ele(NODE *root,int val);

void min_ele(NODE *root);

void max_ele(NODE *root);

NODE *delete(NODE *root,int key);

int height(NODE *root);

void print_level(NODE *root,int level);

void level_order(NODE *root); 

int cnt_node(NODE *root);

NODE * delete_rec(NODE *root,int key);

NODE * find_max(NODE *root);

NODE *root = NULL;

int main(void)
{
	int ch; 
	while (1) {
		
		printf("\n\t\t 1.Insertion \n\t\t 2.Display\n\t\t 3.0 to Exit"); 
		printf("\n\t\t 4.Search\n\t\t 5.Find min\n\t\t 6.find Max \n\t\t 7.Delete");
		printf("\n\t\t 8.find Height \n\t\t 9.Level order\n\t\t 10.Cnt_no_nodes");
		printf("\n\t\t 11.Delete_rec");
	
		printf("\nEnter choice:");	
		scanf("%d",&ch);
		
		switch(ch) {
		
			case 1:
				
				printf("Enter num:");
				scanf("%d",&val);
				root = insertion(root,val);
				break;
			
			case 2:
				display(root);
				break;
		
			case 0:
				exit(0);
		
			case 4:
				printf("Enter key to search:");
				scanf("%d",&val);
				search_ele(root,val);
				break;
		
			case 5:
				min_ele(root);
				break;
		
			case 6:
				max_ele(root);
				break;
		
			case 7:
				printf("Enter key to Delete:");
				scanf("%d",&val);
				delete(root,val);
				break;
		
			case 8:
				printf("height :%d\n",height(root));
				break;
		
			case 9:
				level_order(root);
				break;
		
			case 10:
				printf("Total nodes :%d\n",cnt_node(root));
				break;
		
			case 11:
				printf("Enter key to Delete:");
				scanf("%d",&val);
				delete_rec(root,val);
				break;
		
			default :
				printf("ooppss..!\n");
		}
	}
}


NODE *insertion(NODE * root,int val)
{
	NODE *tmp,*ptr,*prv = NULL;
	ptr = root;
	
	while (ptr!=NULL) {
		
		prv = ptr;
		
		if((ptr->data) > val)
				
			ptr = ptr ->lchild;
		
		else if((ptr->data) < val)
				
			ptr = ptr -> rchild;
		
		else{
			printf("Dulpicate Element\n");
			//return root;
		}
	}
	tmp = (NODE *)malloc(sizeof(NODE));
	tmp -> data = val;
	tmp ->lchild = NULL;
	tmp ->rchild = NULL;
	
	if (prv == NULL)
		root = tmp;
	
	else if(val < prv->data)
		prv->lchild = tmp;
	
	else
		prv->rchild = tmp;

	return root;
}


void display(NODE *root)
{
	NODE *tmp = root;
	static int cnt = 0;
		
	if(tmp)	{
		
		cnt++;
		display(root ->lchild);
		printf("[%d->]",tmp -> data);
		display(root ->rchild);
	}
	//printf("total nodes are :%d\n",cnt);
}


void search_ele(NODE * root,int key)
{
	NODE *ptr = NULL;
	int flag = 0;
	int cnt = 0;
	
	if (root == NULL) {
		
		printf("BST Is Empty ....!\n");
		//exit(0);
	}
	ptr = root;
	
	while (ptr != NULL) {
		
		cnt++;
		
		if (key < ptr -> data )
			ptr = ptr -> lchild;
		
		else if(key > (ptr -> data))
			ptr = ptr -> rchild;
		
		else {
			flag = 1;
			break;
		}
	}
	if (flag == 1) {
		flag = 0;
		printf("%d is found at level %d ..!\n",ptr -> data,cnt-1);
	}
	else
		printf("Key is not found..\n");
}


void min_ele(NODE *root)
{
	NODE *ptr = NULL;
	NODE *prv = NULL;
	int cnt = 0;
	
	if (root == NULL) {
		printf("BST Is Empty ....!\n");
		exit(0);
	}
	ptr = root;
	
	while (ptr != NULL) {
		cnt++;
		prv = ptr;
		ptr = ptr -> lchild;
	}
	printf("MIn key is :%d\n found at %d level",prv -> data,cnt-1);
}


void max_ele(NODE *root)
{
	NODE *ptr = NULL;
	NODE *prv = NULL;
	int cnt = 0;
	
	if (root == NULL) {
		printf("BST Is Empty ....!\n");
		exit(0);
	}
	ptr = root;
	
	while (ptr != NULL) {
		cnt++;
		prv = ptr;
		ptr = ptr -> lchild;
	}
	printf("MIn key is :%d\n found at %d level",prv -> data,cnt-1);
}


NODE *delete(NODE *root,int key)
{
	NODE *ptr,*par,*child,*succ,*parsucc;
	ptr = root;
	
	while (ptr != NULL) {
		
		if(key == ptr -> data)
			break;
		par = ptr;
		
		if(key < ptr -> data)
			ptr = ptr -> lchild;
		
		else
			ptr = ptr -> rchild;
	}
	if (ptr == NULL) {
		
		printf("key not present in d list..!\n ");
		return root;
	}
	if (ptr->lchild != NULL && ptr ->rchild != NULL) {
		
		parsucc = ptr;
		succ = ptr -> rchild;
		
		while (succ -> lchild != NULL) {
			parsucc = succ;
			succ = succ -> lchild;
		}
		
		ptr -> data = succ -> data;
		ptr = succ;
		par = parsucc;
	}
	if (ptr -> lchild != NULL)
		child = ptr -> lchild;
	
	else
		child = ptr -> rchild;
	
	if(par == NULL)
		root = child;
	
	else if(ptr = par -> lchild)
		par -> lchild = child;
	
	else
		par -> rchild = child;
	
	free(ptr);
	return root;
}


int height (NODE *root)
{
	int a,b;
	NODE *tmp ;
	tmp = root;
	
	if (root == NULL)
		return 0;
	
	a = height (tmp->lchild);
	b = height (tmp->rchild);
	
	if (a > b)
		return a+1;
	
	else
		return b+1;
}


void level_order(NODE *root) 
{
	int h;
	int i;
	h = height(root);
	
	for (i = 1 ;i <= h; i++) {
	
		print_level(root,i);
	}
}


void print_level(NODE *root,int level)
{
	if (root == NULL)
		return ;
	
	if (level == 1)
		printf("%d ",root -> data);
	
	else if (level > 1) {
		
		print_level(root -> lchild,level-1);
		print_level(root -> rchild,level-1);
	}
}


int cnt_node(NODE *root)
{
	if(root == NULL)
		return 0;
	
	return cnt_node(root -> lchild)+cnt_node(root -> rchild) + 1;
}


NODE * delete_rec(NODE *root,int key)
{
	NODE * tmp , *tmp1;
	tmp = root;
	
	if (root == NULL) {
		
		printf("BST is empty..!\n");
		return root;
	}
	
	else if(tmp -> data < key)
		root->rchild =delete_rec(root->rchild,key);  
	
	else if(tmp -> data > key)
		root->lchild =delete_rec(root->lchild,key);
	
	else {
		
		if (root -> lchild == NULL && root -> rchild == NULL) {
			tmp = root;
			free(tmp);
			root = NULL;
		}
		
		else if (root -> lchild == NULL) {
			tmp = root;
			root = root -> rchild;
			free(tmp);
		}
		
		else if (root -> rchild == NULL) {
			tmp = root;
			root = root -> lchild;
			free(tmp);
		}
		
		else {
			tmp1 = find_max(root -> lchild);
			root -> data = tmp1 -> data;
			root -> lchild = delete_rec(root->lchild,tmp1 -> data);
		}
	}
	return root;
}


NODE * find_max(NODE *root)
{
	NODE *tmp = NULL;
	tmp = root;
	
	while (tmp -> rchild != NULL) {
		tmp = tmp -> rchild;
	}
	
	return tmp;
}
