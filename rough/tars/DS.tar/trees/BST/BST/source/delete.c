#include	"header.h"

TREE *deleted(TREE *root, int value)
{
	TREE *temp = NULL;

	if(root == NULL) {

		printf("element %d not found\n", value);
		return root;
	}

	if(value < root -> data)

		root -> left = deleted(root -> left, value);

	else if(value > root -> data)

		root -> right = deleted(root -> right, value);

	else {

		if(root -> left == NULL) {

			temp = root -> right;
			free(root);
			return temp;
		}

		else if(root -> right == NULL) {

			temp = root -> left;
			free(root);
			return temp;
		}

		temp = max_bst(root -> left);

		root -> data = temp -> data;

		root -> left = deleted(root -> left, temp -> data);
	}
	return root;
}
