#include	"header.h"

int free_tree(TREE *root)
{
	if(root) {

		free_tree(root -> left);

		free_tree(root -> right);

		free(root);

		root = NULL;
	}
	return 0;
}
