#include	"header.h"

int height_bst(TREE *root)
{
	int a = 0;
	int b = 0;

	if (root == NULL) 
		return 0;

	a = height_bst(root->left);
	b = height_bst(root->right);

	if (a > b)
		return (a + 1);
	else 
		return (b + 1);
	
	return 0;
}	
