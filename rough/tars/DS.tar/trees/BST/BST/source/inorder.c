#include	"header.h"

void inorder(TREE *root)
{
	if(root) {

		inorder(root -> left);

		printf("%d\t", root -> data);

		inorder(root -> right);
	}
}
