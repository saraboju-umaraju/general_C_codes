#include	"header.h"

TREE *insert(TREE *root, TREE *new)
{
	if(root == NULL)

		return new;
	
	else if(new -> data > root -> data) 

		root -> right = insert(root -> right, new);

	else if(new -> data < root -> data) 

		root -> left = insert(root -> left, new);

	return root;
}
