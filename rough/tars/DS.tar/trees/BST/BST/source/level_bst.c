#include	"header.h"

TREE *level_bst(TREE *temp)
{
	int i = 0;
	int h = 0;
	
	if (temp == NULL) {

		printf("\nTree is empty...\n");
		return temp;
	}

	h = height_bst(temp);

	for(i = 0; i <= h; i++)
		level_order(temp, i);
}
