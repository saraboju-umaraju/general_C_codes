#include	"header.h"

TREE *level_order(TREE *temp, int level)
{		
	if (temp == NULL) 
		return temp;

	if (level == 1)
		printf ("%d\t", temp->data);
	
	else if (level > 1) {

		level_order(temp->left, level - 1);
		level_order(temp->right, level - 1);
	}
}
