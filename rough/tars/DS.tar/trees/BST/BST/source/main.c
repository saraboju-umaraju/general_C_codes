#include	"header.h"

int main(void)
{
	TREE *root = NULL;
	TREE *temp = NULL;
	int ch;
	int value;

	while(1) {

		printf(".....Welcome to GES ltd.....\n1: Insertion\n2: Deletion\n3: Display\n4: Search\n5: Height\n6: Exit\n.....Thank you GES.....\n"
				"Enter your choice from menu\n");
		ch = valid_int();

		switch(ch) {

				case 1:

					temp = (TREE *)malloc(sizeof(TREE));
					
					printf("Enter the value to insert\n");
					temp -> data = valid_int();

					temp -> left = NULL;
					temp -> right = NULL;

					root = insert(root, temp);
					break;

				case 2:

					printf("Enter the value to delete\n");
					value = valid_int();

					if(root == NULL) {

						printf("tree is empty\n");
						break;
					}

					root = deleted(root, value);
					break;

				case 3:

					printf(".....MENU.....\n1: In-order\n2: pre-order\n3: post-order\n4: level-order\n.....END.....\nEnter your choice\n");
					ch = valid_int();

					switch(ch) {

							case 1:
								
								if(root == NULL)

									printf("tree is empty\n");

								else {
									printf("\nElements in tree are\n");
									inorder(root);
									printf("\n");
								}
								break;

							case 2:
								
								if(root == NULL)

									printf("tree is empty\n");

								else {
									printf("\nElements in tree are\n");
									preorder(root);
									printf("\n");
								}
								break;

							case 3:
								
								if(root == NULL)

									printf("tree is empty\n");

								else {
									printf("\nElements in tree are\n");
									postorder(root);
									printf("\n");
								}
								break;

							case 4:
									
								temp = root;

								printf("Elements in tree are\n");
								
								level_bst(temp);
								printf("\n");
								
								break;

							default: printf("Invalid choice\n");
					}
					break;

				case 4:

					printf("Enter the element to search\n");
					value = valid_int();

					if(root == NULL)

						printf("tree is empty\n");
					
					else
						value = search(root, value);
					break;

				case 5:

					temp = root;

					value = height_bst(temp);
					printf("height of tree is: %d\n", value);

					break;

				case 6:
					exit(0);
					//free_tree(root);
					//return 0;

				default: printf("Invalid choice\n");
		}
	}
	return 0;
}
