#include	"header.h"

TREE *max_bst(TREE *root)
{
	TREE *temp = root;

	while(temp -> right != NULL)

		temp = temp -> right;
	
	return temp;
}
