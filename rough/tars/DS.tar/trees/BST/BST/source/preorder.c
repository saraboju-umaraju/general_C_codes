#include	"header.h"

void preorder(TREE *root)
{
	if(root) {

		printf("%d\t", root -> data);

		preorder(root -> left);

		preorder(root -> right);
	}
}
