#include	"header.h"

int search(TREE *root, int value)
{
	if(root == NULL) {

		printf("element %d is not found\n", value);
		return 0;
	}

	else if(root -> data == value)

		printf("element %d is present in tree\n", value);

	else if(root -> data < value)

		search(root -> right, value);

	else if(root -> data > value)

		search(root -> left, value);

	return 0;
}
