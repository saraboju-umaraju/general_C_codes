#include	"myheader.h"

int second_least(node* root)
{
	node* second = root;
	if(root == NULL){
		printf("Tree is empty\n");
		return 0;
	}

	if(!(root->left || root->right)){
		printf("Tree has only one element\n");
		return 0;
	}

	while(root->left){
		second = root;
		root = root->left;
	}

	if(root->right){
		root = root->right;
		if(root->left == NULL){
			return root->data;
		}
		while(root->left){
			root = root->left;
		}

		return root->data;
	}

	return second->data;
}
