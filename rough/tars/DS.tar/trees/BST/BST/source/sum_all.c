#include	"myheader.h"

int sum_all(node* root)
{
	int sum = 0;

	if(root == NULL){
		return sum;
	}

	sum = root->data + sum_all(root->left) + sum_all(root->right);
//	sum = root->data;
//	sum += sum_all(root->left);
//	sum += sum_all(root->right);

	return sum;
}
