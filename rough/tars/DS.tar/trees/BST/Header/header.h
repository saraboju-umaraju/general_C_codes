#include	<stdio.h>
#include	<string.h>
#include	<stdlib.h>

typedef struct BST {

		struct BST *left;
		int data;
		struct BST *right;

}NODE;


void insert_bst ( NODE ** , int );
void inorder_bst ( NODE * );
void inorder_bst_norec ( NODE * );
void postorder_bst ( NODE * );
void preorder_bst ( NODE * );
int inte_val_func ( void );
NODE *delete_bst (NODE *, int );
NODE *delete_bst_norec (NODE *, int );
NODE *max_bst (NODE *);
NODE *min_bst (NODE *);
int height_bst ( NODE * );
NODE *level_bst ( NODE * );
NODE *print_level_bst ( NODE * , int );
int sum_of_bst ( NODE * );
NODE *second_least_bst ( NODE *);
NODE *mirror_image(NODE *);
