/*	
 *	Function to Convert BST to Doubly Linked list
 *  temp --> Root of Binary Tree 
 *	head --> Pointer to head node of created doubly linked list
 */

#include	"header.h"

NODE* BSTtoDLL (NODE *temp, NODE **head)
{
	// Base Case
	if ( temp == NULL )
		return NULL;

	BSTtoDLL (temp->right, head);			// Recursively convert right subtree

	temp->right = *head;				// insert temp into DLL

	if ((*head) != NULL )				// change left pointer of prev head
		(*head)->left = temp;

	(*head) = temp;						// Change head of Doubly Linked list

	BSTtoDLL (temp->left, head);			// Recursively convert left subtree
}
