#include	"header.h"

int main ( void )
{

	NODE *root = NULL;
	NODE *temp = NULL;
	NODE *head = NULL;
	char ch;
	int choice = 0;
	int value = 0;
	int key = 0;
	int height = 0;
	int sum = 0;

	while ( 1 ) {

		printf ("\n\t\t*****MENU*****\n"
				"Enter 1 to insert into bst\n"
				"Enter 2 for Inorder traversal\n"
				"Enter 3 for Post order traversal\n"
				"Enter 4 for Pre order traversal\n"
				"Enter 5 to delete a key in the BST (with recursion)\n"
				"Enter 6 to delete a key in the BST (without recursion)\n"
				"Enter 7 to find the max in the BST\n"
				"Enter 8 to find the min in the BST\n"
				"Enter 9 to find the height of the BST\n"
				"Enter 10 for level order\n"
				"Enter 11 to convert BST to DLL\n"
				"Enter 12 to find the sum of bst\n"
				"Enter 13 to find the second least element in BST\n"
				"Enter 14 for inorder traversal (without recursion)\n"
				"Enter 15 for mirror image\n"
				"Enter 16 to quit\n"
				"\nPlease enter your choice: ");
	
		choice = inte_val_func ( );
	
		switch ( choice ) {

		case 1:
			
			printf ("\nYou are now inserting the elements...\n");
			printf ("\nEnter an element to insert into the tree: ");
			value = inte_val_func ( );

			insert_bst ( &root, value );
		
			break;

		case 2:
		
			printf ("This is inorder \n");
	
			inorder_bst ( root );

			break;

		case 3:

			printf ("This is postorder \n");
		
			postorder_bst ( root );
			
			break;

		case 4:

			printf ("This is pre order \n");
			
			preorder_bst ( root );

			break;

		case 5:

			printf ("\nEnter key element to delete: ");
			key = inte_val_func ( );

			root = delete_bst ( root, key );
	
			break;

		case 6:
	
			printf ("\nEnter key element to delete: ");
			key = inte_val_func ();
			root = delete_bst_norec ( root, key );

			break;

		case 7:
				
			temp = max_bst ( root );
			printf ("Max element in the bst is: %d\n", temp->data );
			
			break;

		case 8:

			temp = min_bst ( root );
			printf ("Min element in the bst is: %d\n", temp->data );
		
			break;

		case 9:
			
			temp = root;
			height = height_bst ( temp );
			printf ("\nHeight of the tree is %d\n", height );

			break;

		case 10:
			
			temp = root;
			printf ("\nThis is level order: \n");
			temp = level_bst ( temp );

			break;

		case 11:
				
				printf ("WARNING: All the Above options may give undefined behaviour, selecting this option will lead to exit of your application, Do you want to proceed (y/n): ");
				ch = getchar();
				getchar();
				if ( ch == 'y' ) { 			
					temp = root;	
					temp = BSTtoDLL ( temp, &head);
					if ( root != NULL ) {
						printf ("Converted tree to linked list\n");
						head = display ( head );				
						return 0;
					} else {
						printf ("Conversiont failed\n");
						return 0;
					}
				} else if ( ch == 'n' ) {
					break;
				} else {
					printf ("Invalid Choice\n");
					break;
				}

				break;

		case 12:
	
			sum = sum_of_bst(root);
			if ( sum == 0 )
				break;
			else
				printf ("Sum of the bst = %d\n", sum );
	
			break;

		case 13:

			root = second_least_bst ( root );
			if ( root == NULL ) {
				printf ("second least element is not found as tree is empty\n");
				break;
			}

			break;

		case 14:

			printf("This is inorder without recursion\n");

			inorder_bst_norec(root);
			break;


		case 15:

			printf("To change into mirror image\n");

			mirror_image(root);
			break;

		case 16:

			printf ("\nThank you, You're now exiting...\n");
			return 0;

		default:

			printf ("WARNING: Invalid choice entered, Please try again...\n");

		}

	}

	return 0;

}
