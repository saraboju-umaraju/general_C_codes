#include	"header.h"

NODE *delete_bst(NODE *root, int key)
{

	NODE *temp = NULL;
	NODE *next = NULL;

	if ( root == NULL ) {
		printf("Element Not Found\n");
		return root;
	}
	if ( key < root->data) 
		root->left =  delete_bst(root->left, key);

	else if ( key > root->data) 
		root->right =  delete_bst(root->right, key);

	else  {
			
		if ( ( root->left != NULL ) && ( root->right != NULL ) ) {

			next = root->right;
			while ( next->left )
				next = next -> left;
			
			root->data = next->data;
			root->right = delete_bst ( root->right, next->data );

		} else {

			temp = root;
			if ( root->left != NULL )
				root = root->left;
			else if ( root->right != NULL )
				root = root->right;
			else
				root = NULL;
		
			free ( temp );
			temp = NULL;
		}

	}

	return root;

}
