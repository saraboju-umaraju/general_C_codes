#include	"header.h"

NODE *delete_bst_norec ( NODE *root, int key )
{
	NODE *temp = root;			//temporary pointer to store root and for traversal
	NODE *parent = NULL;		//parent pointer to strore address of parent of a node to be deleted
	NODE *child = NULL;			//child pointer to store the address of child node.
	NODE *succ = NULL;			//node to be deleted
	NODE *parsucc = NULL;		//parents successer to store the updated links

	if ( root == NULL ) {
		printf ("No elements in tree...!!!\n");
		return root;
	}
	
	while (temp != NULL) {

		if ( key == temp->data ) 
			break;

		parent = temp;

		if ( key < temp->data )
			temp = temp->left;	
		else 
			temp = temp->right;
	}

	if ( temp == NULL ) {
		printf ("Element not present in the list...!!!\n");
		return root;
	}

	if ( (temp->left != NULL) && (temp->right != NULL) ) {
		
		parsucc = temp;	
		succ = temp->right;
		
		while ( succ->left != NULL ) {
			parsucc = succ;
			succ = succ->left;
		}

		temp->data = succ->data;
		temp = succ;
		parent = parsucc;
	
	}

	/* node havinf 1 or no child */
	if ( temp->left != NULL )		//node to be deleted has left child
		child = temp->left;
	else							//node to be deleted has right child
		child = temp->right;

	if ( parent == NULL )			//node to be deleted is root node
		root = child;

	else if ( temp == parent->left )	//node is left child of its parent
		parent->left = child;

	else					//node is right child of its parent
		parent->right = child;
	
	free (temp);
	temp = NULL;

	return root;

}
		
