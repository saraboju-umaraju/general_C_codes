#include	"header.h"

void display ( NODE * head )
{

	NODE *temp = head;

	if ( head == NULL ) {

		printf ("\nList is empty, There's nothing to print...\n");
		return;

	}

	while ( temp ) {

		printf ("%d ", temp->data );
		temp = temp->right;

	}
	
	temp = NULL;

}
