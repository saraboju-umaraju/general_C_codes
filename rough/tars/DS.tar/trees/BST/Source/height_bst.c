#include	"header.h"

int height_bst ( NODE *temp )
{

	int h_left = 0;
	int h_right = 0;

	if ( temp == NULL ) 
		return 0;

	h_left = height_bst ( temp->left );
	h_right = height_bst ( temp->right );

	if ( h_left > h_right )
		return ( 1 + h_left );
	else 
		return ( 1 + h_right );
	
	return 0;

}	
