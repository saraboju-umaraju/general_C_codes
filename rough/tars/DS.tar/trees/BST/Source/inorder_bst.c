#include	"header.h"

void inorder_bst ( NODE *p )
{

	if ( p ) {

		inorder_bst ( p->left );
		printf ("%d ", p->data );
		inorder_bst ( p->right );
	} 

}
