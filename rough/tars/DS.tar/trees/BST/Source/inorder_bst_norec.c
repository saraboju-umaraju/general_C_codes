#include	"header.h"

void inorder_bst_norec(NODE *root)
{
	NODE *curr = root;
	NODE *prev = root;

	while(curr) {

		if(curr -> left == NULL) {

			printf("%d ", curr -> data);

			curr = curr -> right;
		} else {

			prev = curr -> left;

			while(prev -> right != NULL && prev -> right != curr)

				prev = prev -> right;

			if(prev -> right == NULL) {

				prev -> right = curr;
				curr = curr -> left;
			} else {

				prev -> right = NULL;

				printf("%d ", curr -> data);

				curr = curr -> right;
			}
		}
	}
}
