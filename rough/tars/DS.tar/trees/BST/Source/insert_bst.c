#include	"header.h"

void insert_bst ( NODE **p, int value )
{

	NODE *new_node = NULL;

	if ( (*p) == NULL ) {

		if ( ( !( new_node = ( NODE * ) malloc ( sizeof ( NODE ) ) ) ) ) {

			printf ("\nWARNING: MEMORY ALLOCATION FAILURE...\n");
			return;

		}

		new_node->data = value;
		new_node->left = NULL;
		new_node->right = NULL;

		(*p) = new_node;

	}

	if ( ( (*p)->data ) > value ) 	
		insert_bst ( &((*p)->left), value );
	else if ( ( (*p)->data ) < value )
		insert_bst ( &((*p)->right), value );

}
