#include	"header.h"

NODE *insert_bst_nrec( NODE *root, int value )
{
	NODE *temp = NULL;
	if( ! ( temp = (NODE *) malloc ( sizeof ( NODE ) ) ) ) {
		printf(" error in malloc\n ");
		return root;
	}
	
	if( root == NULL ) {  // if there are no nodes
		temp -> data = value;
		temp -> left = temp -> right = NULL;
		root = temp ;
		return root;

	}
	
	NODE *temp1 = root;			//temp vatiable to store root
	temp -> data = value;		//adding data to temp pointer
	temp -> left = temp -> right = NULL;	//assigning pointers to null
	while( (temp1 -> left != NULL) || ( temp1 -> right != NULL )) {				//if left and right nodes are present
		
		if(  temp1 -> data > temp -> data ) {				//if data is greater that root node

			if( temp1 -> left == NULL ) {					//if there is no left child
				temp1 -> left = temp;
				return root;
			}
			temp1 = temp1 -> left;					
		} else if( temp1 -> data < temp -> data ) {				//if data is smaller than root node
	
			if( temp1 -> right == NULL ) {						//if there is no right child
				temp1 -> right = temp;
				return root;
			}
			temp1 = temp1 -> right ;		
		}
		
	}

	if( temp1 -> data >= temp -> data ) {					//adding data at the node
		temp1 -> left = temp ;

	}else {
		temp1 -> right = temp;
	}

	return  root;
}
	
