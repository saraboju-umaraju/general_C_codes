#include	"header.h"

NODE *level_bst ( NODE *temp1 )
{

	int i = 0;
	int h = 0;
	
	if ( temp1 == NULL ) {

		printf ("\nTree is empty...\n");
		return temp1;

	}

	h = height_bst ( temp1 );

	for ( i = 0; i <= h; i++ )
		print_level_bst ( temp1, i );

}
