#include	"header.h"

NODE *max_bst ( NODE *root )
{

	NODE *temp = root;

	if ( root != NULL ) {

		while ( temp->right != NULL )
			temp = temp->right;
		
		return temp;

	}

	return root;

}
