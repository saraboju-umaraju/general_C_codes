#include    "header.h"

NODE *min_bst ( NODE *root )
{

    NODE *temp = root;

    if ( root != NULL ) {

        while ( temp->left != NULL )
            temp = temp->left;

        return temp;

    }

    return root;

}

