#include	"header.h"

NODE *mirror_image(NODE *root)
{
	NODE *temp = NULL;

	if(root == NULL)

		return root;

	/*root -> left = (int *)((int)root -> left ^ (int)root -> right);
	root -> right = (int *)((int)root -> left ^ (int)root -> right);
	root -> left = (int *)((int)root -> left ^ (int)root -> right);*/

	temp = root -> left;
	root -> left = root -> right;
	root -> right = temp;

	root -> left = mirror_image(root -> left);
	root -> right = mirror_image(root -> right);

	return root;
}
