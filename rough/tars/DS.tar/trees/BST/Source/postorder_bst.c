#include	"header.h"

void postorder_bst ( NODE *p )
{

	if ( p ) {

		postorder_bst ( p->left );
		postorder_bst ( p->right );
		printf ("%d ", p->data );

	}

}
