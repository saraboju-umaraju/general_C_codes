#include	"header.h"

void preorder_bst ( NODE *p )
{

	if ( p ) {

		printf ("%d ", p->data );
		preorder_bst ( p->left );
		preorder_bst ( p->right );

	}

}
