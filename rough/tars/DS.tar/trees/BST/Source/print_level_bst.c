#include	"header.h"

NODE *print_level_bst ( NODE *root, int level )
{
		
	if ( root == NULL ) 
		return root;

	if ( level == 1 )
		printf ("%d ", root->data );
	
	else if ( level > 1 ) {

		print_level_bst ( root->left, level - 1 );
		print_level_bst ( root->right, level - 1 );

	}

}
