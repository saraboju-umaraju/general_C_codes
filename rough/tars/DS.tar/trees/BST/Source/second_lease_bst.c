#include	"header.h"

NODE *second_least_bst ( NODE *root )
{
	NODE *temp = root;

	if ( root == NULL ) {
		
		printf ("Tree is empty\n");
		return root;

	}

	if ( ( root->left == NULL ) && ( root->right == NULL ) ) {
		
		printf ("Only one element in the list\n");
		return root;
	
	}

	if ( ( root->left != NULL ) && ( root->right != NULL ) ) {

		while ( temp->left->left != NULL ) 	
			temp = temp->left;

		if ( temp->left ) {
			
			printf ("Second least element = %d\n", temp->data );
			return root;

		}

		if ( temp->left->left ==  NULL ) {
		
			temp = temp->right;
			while ( temp->left != NULL )
				temp = temp->left;
			
			printf ("Second least element = %d\n", temp->data );

			return root;
		
		}

		printf ("Second least element = %d\n", temp->data );

		return root;

	}

	if ( ( temp->left == NULL ) && ( temp->right != NULL ) ) {
		
		temp = temp->right;
		while ( temp->left != NULL )
			temp = temp->left;

		printf ("Second least element = %d\n", temp->data );

		return root;

	}
	
	if ( ( temp->left != NULL ) && ( temp->right == NULL ) ) {

		while ( temp->left->left != NULL ) 
			temp = temp->left;

		if ( temp->left->left == NULL ) {

			temp = temp->left;
			if ( temp->right != NULL ) {
				
				temp = temp->right;
				printf ("Second least element = %d\n", temp->data );

				return root;

			}

			printf ("Second least element = %d\n", temp->data );
			
			return root; 

		} 

		printf ("second least element = %d\n", temp->data );

		return root;

		
	}

	return root;
}
