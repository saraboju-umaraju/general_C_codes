#include	"header.h"

int sum = 0;

int sum_of_bst ( NODE *root )
{
	if ( root == NULL ) {
		printf ("List is empty\n");
		return sum;
	}

	sum = sum + root->data;
	sum = sum_of_bst (root->left);
	sum = sum_of_bst (root->right);

	return sum;
}
