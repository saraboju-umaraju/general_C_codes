#include	"header.h"

NODE *insert( NODE *root, int value )
{
	NODE *temp = NULL;
	if( ! ( temp = (NODE *) malloc ( sizeof ( NODE ) ) ) ) {
		printf(" error in malloc\n ");
		return root;
	}
	
	if( root == NULL ) {  // if there are no nodes
		temp -> data = value;
		temp -> left = temp -> right = NULL;
		root = temp ;
		return root;

	}
	
	NODE *temp1 = root;
	temp -> data = value;
	temp -> left = temp -> right = NULL;
	while( (temp1 -> left != NULL) || ( temp1 -> right != NULL )) {
		
		if(  temp1 -> data > temp -> data ) {

			if( temp1 -> left == NULL ) {
				temp1 -> left = temp;
				return root;
			}
			temp1 = temp1 -> left;
		} else if( temp1 -> data < temp -> data ) {
	
			if( temp1 -> right == NULL ) {
				temp1 -> right = temp;
				return root;
			}
			temp1 = temp1 -> right ;
		}
		
	}
	if( temp1 -> data >= temp -> data ) {
		temp1 -> left = temp ;

	}else {
		temp1 -> right = temp;
	}

	return  root;
}
	
