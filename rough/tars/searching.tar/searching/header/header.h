#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>


int n;

int gv;



int intval_input(void);

int *input_array(void);

int *merge_sort(void);

void linear_search(void);

void binary_search(void);

void display(int *,int);
