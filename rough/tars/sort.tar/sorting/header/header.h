#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>

int gv;

int n;

int intval_input(void);

void display(int *, int);

int *input_array(void);

void bubble_sort(void);

void selection_sort(void);
 
void insertion_sort(void);

void merge_sort(void);

void quick_sort(void);

void swap_arr(int *, int *);


